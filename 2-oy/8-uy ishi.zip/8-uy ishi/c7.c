#include <stdio.h>

int main() {
    int n, m;
    printf("n = ");
    scanf("%d", &n);
    printf("m = ");
    scanf("%d", &m);

    int number = 2; // Birinchi tub son 2 dan boshlanadi

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            // Keyingi tub sonni topamiz
            int a;
            do {
                a = 1; // Sonni tub deb faraz qilamiz
                for (int k = 2; k * k <= number; k++) {
                    if (number % k == 0) {
                        a = 0; // Tub emas
                        break;
                    }
                }
                if (!a) number++;
            } while (!a);

            printf("%d ", number);
            number++;
        }
        printf("\n");
    }


}
