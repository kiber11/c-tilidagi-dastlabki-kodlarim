
#include<stdio.h>
int main(){
int n,m;scanf("%d %d",&n,&m);
int i,j;
int k=1;
for(i=1;i<=n;i++){
    for(j=1;j<=m;j++){
        printf("%d\t",k);
        k+=1;
    }
    printf("\n");
}
}
