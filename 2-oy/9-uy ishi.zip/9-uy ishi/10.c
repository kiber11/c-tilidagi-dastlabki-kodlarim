#include<stdio.h>
void ikkilik(int a){
int qoldiq=0,sum=0;
while(a>=1){
    qoldiq=qoldiq*10+a%2;
    a=a/2;
}
while(qoldiq>0){
    sum=sum*10+qoldiq%10;
    qoldiq=qoldiq/10;
}
printf("%d",sum);
}
int main(){
int a; printf("a="); scanf("%d",&a);
ikkilik(a);
}
