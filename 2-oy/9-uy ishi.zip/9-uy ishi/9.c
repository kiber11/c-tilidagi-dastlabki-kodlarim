#include<stdio.h>
void jufttoq(int a){
if(a%2==0){
    printf("juft");
}
else{
    printf("toq");
}
}
int main(){
int a; printf("a="); scanf("%d",&a);
jufttoq(a);
}
