#include<stdio.h>
int main(){
int k,n,i=1;
printf("k="); scanf("%d",&k);
printf("n="); scanf("%d",&n);
do{


    printf("%d\n",k);
    i=i+1;
}

while(i<=n);
}
