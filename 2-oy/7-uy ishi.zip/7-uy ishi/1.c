#include <stdio.h>

int main() {
    int x, y,i;
    printf("x = ");
    scanf("%d", &x);
    printf("y = ");
    scanf("%d", &y);

    for (  i = 0; i <= x ;i=i+y) {

    }

    printf("%d ", x - (i - y));


}
